F10: show/hide Crosshair
Alt+F10: quit
